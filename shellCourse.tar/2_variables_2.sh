#!/bin/bash
# Programa para revisar la declaración de variables

echo "Opcion nombre pasada del script anterior:$nombre"