#!/bin/bash
# Programa para ejemplificar el uso de la descarga de información desde internet usando el comando wget
# Autor: David Ochoa - github:Sochoag

echo "Descargar información de internet"
wget https://www.zdnet.com/a/img/resize/9a0968b08b072c239f886879b6ac03e05e07fdbf/2023/01/30/785a5ea4-67e2-4068-8116-4fe0225b0dcf/zdnet-best-cheap-3d-printers.jpg