#!/bin/bash
bash -x 2_variables.sh # General
bash -x 2_variables.sh # Detallado