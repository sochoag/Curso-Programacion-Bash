#!/bin/bash
# Reto 1

option=0
result=0

echo "Opcion: $option"
echo "Resultado: $result"