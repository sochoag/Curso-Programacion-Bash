#!/bin/bash
# Programa que permite ejemplificar el empaquetamiento con tar
# Autor: David Ochoa - Github: Sochoag

echo "Empaquetar todos los scripts"
tar -cvf shellCourse.tar *.sh